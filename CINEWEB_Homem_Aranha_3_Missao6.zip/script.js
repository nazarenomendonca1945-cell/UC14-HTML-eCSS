// ============================================
// CINEWEB — HOMEM-ARANHA 3 / CINE AWARDS
// MISSÃO 6 — JavaScript
// ============================================

const votes = {
  "Melhor Filme": {
    "Homem-Aranha 3": 14,
    "Homem-Aranha 2": 10,
    "Homem-Aranha": 8
  },
  "Melhor Ator": {
    "Tobey Maguire": 16,
    "James Franco": 9,
    "Thomas Haden Church": 7
  },
  "Melhor Atriz": {
    "Kirsten Dunst": 13,
    "Bryce Dallas Howard": 10,
    "Rosemary Harris": 9
  },
  "Melhor Direção": {
    "Sam Raimi": 17,
    "Marc Webb": 8,
    "Jon Watts": 7
  }
};

const form = document.getElementById("voteForm");
const message = document.getElementById("message");
const totalVotesElement = document.getElementById("totalVotes");
const resultsGrid = document.getElementById("resultsGrid");
const clearBtn = document.getElementById("clearBtn");
const showResultsBtn = document.getElementById("showResultsBtn");

// INTERAÇÃO 1 — calcular total de votos
function calculateTotalVotes() {
  let total = 0;

  Object.values(votes).forEach(category => {
    Object.values(category).forEach(number => {
      total += number;
    });
  });

  return total;
}

function updateTotalVotes() {
  totalVotesElement.textContent = calculateTotalVotes();
}

// INTERAÇÃO 2 — mensagens dinâmicas
function showMessage(text, type = "success") {
  message.textContent = text;
  message.className = "message show";
  message.style.color = type === "error" ? "#ef2435" : "#d9b45d";

  setTimeout(() => {
    message.className = "message";
  }, 4500);
}

// INTERAÇÃO 3 — validação das categorias
function getSelectedVotes() {
  const categories = ["filme", "ator", "atriz", "direcao"];
  const selected = {};

  for (const category of categories) {
    const checked = document.querySelector(
      `input[name="${category}"]:checked`
    );

    if (!checked) return null;

    selected[category] = checked.value;
  }

  return selected;
}

// INTERAÇÃO 4 — registrar votação
form.addEventListener("submit", function(event) {
  event.preventDefault();

  const selected = getSelectedVotes();

  if (!selected) {
    showMessage(
      "⚠️ Escolha um candidato em todas as 4 categorias antes de confirmar.",
      "error"
    );
    return;
  }

  votes["Melhor Filme"][selected.filme]++;
  votes["Melhor Ator"][selected.ator]++;
  votes["Melhor Atriz"][selected.atriz]++;
  votes["Melhor Direção"][selected.direcao]++;

  updateTotalVotes();

  showMessage(
    "🕷️ Voto confirmado! Obrigado por participar do Cine Awards."
  );

  renderResults();

  document.getElementById("resultados").scrollIntoView({
    behavior: "smooth"
  });
});

// INTERAÇÃO 5 — limpar escolhas
clearBtn.addEventListener("click", function() {
  form.reset();

  showMessage("Escolhas limpas. Você pode selecionar novamente.");

  document.getElementById("missao").scrollIntoView({
    behavior: "smooth"
  });
});

// INTERAÇÃO 6 — atualizar resultados
showResultsBtn.addEventListener("click", function() {
  renderResults();
  showMessage("Resultados atualizados!");

  document.getElementById("resultados").scrollIntoView({
    behavior: "smooth"
  });
});

// INTERAÇÃO 7 — criar placar dinamicamente
function renderResults() {
  resultsGrid.innerHTML = "";

  Object.entries(votes).forEach(([categoryName, candidates]) => {
    const card = document.createElement("div");
    card.className = "result-card";

    const title = document.createElement("h3");
    title.className = "result-title";
    title.textContent = categoryName;

    card.appendChild(title);

    const totalCategoryVotes = Object.values(candidates)
      .reduce((sum, value) => sum + value, 0);

    const orderedCandidates = Object.entries(candidates)
      .sort((a, b) => b[1] - a[1]);

    orderedCandidates.forEach(([name, count]) => {
      const percentage = totalCategoryVotes === 0
        ? 0
        : Math.round((count / totalCategoryVotes) * 100);

      const item = document.createElement("div");
      item.className = "result-item";

      item.innerHTML = `
        <div class="result-name">
          <span>${name}</span>
          <span>${count} voto${count !== 1 ? "s" : ""} — ${percentage}%</span>
        </div>
        <div class="bar">
          <div class="bar-fill" style="width: ${percentage}%"></div>
        </div>
      `;

      card.appendChild(item);
    });

    resultsGrid.appendChild(card);
  });
}

// INTERAÇÃO 8 — animação ao escolher candidato
document.querySelectorAll(".candidate input").forEach(input => {
  input.addEventListener("change", function() {
    const category = this.closest(".category");

    category.style.transform = "scale(1.01)";

    setTimeout(() => {
      category.style.transform = "";
    }, 180);
  });
});

// Inicialização
updateTotalVotes();
renderResults();
